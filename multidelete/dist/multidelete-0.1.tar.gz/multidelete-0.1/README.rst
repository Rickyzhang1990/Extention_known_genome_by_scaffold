a multicore tools for deleting lots  of files
